# File for the main game input
# Yeah, we're testing from here
# Let's go Dawn

from random import randint
from sys import exit


class Game(object):

	def __init__(self, start):
		self.quips = [
			"Not so good to hear. Sorry though, gotta leave you alone",
			"And now I guess you've to tour the Island alone ",
			"And now, you've got to learn how to be a better person. Sorry though ve to leave you :(",
			"Ooops, did I just say your residence is ready? Well I guess its a typographical error."
		]
		self.start = start

	def play(self):
		next = self.start

		while True:
			print """
-------------------------------------------------------------------------------		
----   ---                  -------    ----    ----   ----    ---- ---   ----
----     ---              ---- ----    ----    ----   ----    ----  ---  ----
----       ---          ----   ----    ----    ----   ----    ----   --- ----
----       ---        ----  -- ----    ----    ----   ----    ----    -------
----     ---        ----    -- ----    ----    ----   ----    ----     ------
----   ---        ----         ----    -------------------    ----      -----
----------      ----           ----    -------------------    ----       ----

-------------------- ----------------------------------------------------------
			"""
			room = getattr(self, next)
			next = room()

	def death(self):
		print self.quips[randint(0, len(self.quips)-1)]
		exit(1)
#================================================================================

	def chl(self):
		print """

\nNar:	Well, thanks for telling us about your self. I guess Governor Dawn 
	would be happy.
\nGov:	In as much as I know little about you, don't hesitate therefore to
	add more if you so desire. My little Princess Phillipine
	has told me a lot aobut you. Through out your conversations
	with her, for now I think you can stay with us.
	Atleast you're not a cheat though. :) 

		"""
		ch = raw_input(">>> ")

		if ch == "Ok":
			print """
\nGov:	If you've any questions you can ask. Before then, do you love code names?
	If you dont, that's fine. But if you do, you can equally choose one.
			"""
			return 'que'

		elif ch == "Thank you":
			print """
\nGov:	If you've any questions you can ask. Before then, do you love code names?
	If you dont, that's fine. But if you do, you can equally choose one.
			"""
			return 'que'

		elif ch == "Thanks":
			print """
\nGov:	If you've any questions you can ask. Before then, do you love code names?
	If you dont, that's fine. But if you do, you can equally choose one.
			"""
			return 'que'
		else:
			print "You might want to come again with that please"
			print "Now lets roll it back shall we."
			print "And well kindly listen with cock ears this time around"
			return 'chl'

	def que(self):
		print """
\nPhil:	I guess my good friend got some questions to ask.
\nNar:	Not rather a good news, you can't ask Governor just any random questions. 
	For selected ones, please input 'Ask Governor' without the quotes.
	At most 5 questions please.
	If there are none, input 'No Governor'
		"""
		ques = raw_input(">>> ")

		if ques == "Ask Governor":
			print """
\n\tHere are the selected questions. Kindly use the numbers to indicate instead:
\t1. Governor, please with all due respect any rules and regulations in here.
\t2. Governor, please with all due respect, can I please bring a relative or friend too?
\t3. Governor, please with all due respect, I would love a codename.
\t4. Governor, please with all due respect, from here what next?
\t5. Governor, please with all due respect, can I solely come here?
			"""
			gov = raw_input(">>> ")

			if gov == "1":
				print "\nGov:	In here, there are no rules actually, but thing is, play safe."
				return 'que'
			elif gov == "2":
				print "\nGov:	Sure you can, but they would have to pass the 'Cheat test' beforehand."
				return 'que'
			elif gov == "3":
				print "\nGov:	Well, what would that be then?"
				return 'name'
			elif gov == "4":
				print "\nGov:	Wow, nothing. You can go back to your residence peacefully."
				return 'que'
			elif gov == "5":
				print "\nGov:	As many times as you want."
				return 'que'
			else:
				print "I got no idea what that means please."
				return 'que'

		elif ques == "No Governor":
			print "Well, I thought so."
			return 'con'

		else:
			print "You might want to come again with that please"
			return 'que'

	def con(self):
		print """
Nar:	PinkBerry and old friend gets up and tends to leave.
	In a moment Governor recieves a disturbing call.
	Looks at PinkBerry at most times and cathches a glance at old friend.
	He seems not to be happy.
	And the call ends.
"""
		return 'inter'
#======================================================================
	def name(self):

		codename = raw_input(">>> ")
		print """
\nGov:	Wow, the last time I checked, I havn't heard of %r before. :)
	I guess I've to add it to the list of Undisputed Codenames ever.
		""" % codename
		return 'que'
#======================================================================
	def inter(self):
		print """
nGov:	Pinky, did you say you conducted a full research on your friend?
	Whats that name again?
\nNar:	Points to you.
		"""
		nuse = raw_input(">>> ")
		print """
\nGov:	Yes Pinky on %r you had no doubts? Then why this info?
\nNar:	What info Governor? Is something wrong please?
\nGov:	Well I guess I've to press the panic button.
		""" % nuse
		print """
\nGov:	Tell me %r, you go into a house and you find a spell for making money
	and notes on how to teach others to make money. 
	Which would you go for? Notes or Spell?

		""" % nuse
		house = raw_input(">>> ")

		if house == "Notes": # Yes
			print "Well"
			return 'bow'
		elif house == "Spell": # No
			print "I see"
			return 'bow1'
		else:
			print "I got no idea what you means."
			return 'inter'
#========================================================================
	def bow1(self): # No
		print """
\nGov:	You decided to take a shot with bow and arrows. History suggests
	if its taken during the raining season, all 1000s of arrows would fail
	to hit target. Would you go ahead?
		"""
		bowo = raw_input(">>> ")

		if bowo == "Yes":
			print "Well said"
			return 'food2'
		elif bowo == "No":
			print "You've thought right"
			return 'food1'
		else:
			print "I got no idea what you means."
			return 'bow1'
#=============================================================================
	def food2(self): # NOYES
		print """
\nGov:	You have a loaf of bread you would eat when night falls. 
	Your 2 friends are hungry in the morning hours. 
	What do you do? Share or Give?

		"""
		bread3 = raw_input(">>> ")

		if bread3 == "Share": # Yes
			print "Hm, so what is it that I copied?"
			return 'inter_in'
		elif bread3 == "Give": # No
			print "I guess it could all boild down to this"
			return 'inter_out'
		else:
			print "I got no idea what that means."
			return 'food2'

#=============================================================================
	def food1(self): # NoNo
		print """
\nGov:	You have a loaf of bread you would eat when night falls. 
	Your 2 friends are hungry in the morning hours. 
	What do you do? Share or Give?

		"""
		bread = raw_input(">>> ")

		if bread == "Share":
			print "Hm, so what is it that I copied?"
			return 'inter_out'
		elif bread == "Give":
			print "I guess it could all boild down to this"
			return 'inter_out'
		else:
			print "I got no idea what that means."
			return 'food1'
#============================================================================= issues
	def bow2(self): #YesNo
		print """
\nGov:	You have a loaf of bread you would eat when night falls. 
	Your 2 friends are hungry in the morning hours. 
	What do you do? Share or Give?

		"""
		bread1 = raw_input(">>> ")

		if bread1 == "Share":
			print "Hm, so what is it that I copied?"
			return 'inter_in'
		elif bread1 == "Give":
			print "I guess it could all boild down to this"
			return 'inter_out'
		else:
			print "I got no idea what that means."
			return 'bow2'

#===========================================================================
	def bow(self): # Yes
		print """
\nGov:	You decided to take a shot with bow and arrows. History suggests
	if its taken during the raining season, all 1000s of arrows would fail
	to hit target. Would you go ahead?
		"""
		bows = raw_input(">>> ")

		if bows == "Yes":
			print "Well said"
			return 'food'
		elif bows == "No":
			print "You've thought right"
			return 'bow2'
		else:
			print "I got no idea what you means."
			return 'bow'
#===========================================================================
	def food(self): 
		print """
\nGov:	You have a loaf of bread you would eat when night falls. 
	Your 2 friends are hungry in the morning hours. 
	What do you do? Share or Give?

		"""
		bread = raw_input(">>> ")

		if bread == "Share":
			print "Hm, so what is it that I copied?"
			return 'inter_in'
		elif bread == "Give":
			print "I guess it would all boil down to this"
			return 'inter_in'
		else:
			print "I got no idea what that means."
			return 'food'
#============================================================================
	def inter_out(self):
		print """
\nGov:	Well, well, well. So what sources are saying is true.
	Undisclosed reports indicating that you're a
	prodigal figure in light of your bad characters such as greed, uncaring,
	undetermined, ungrateful among others have all been proven.
	Just maybe you were thinking escaping the 'Cheat test' would suffice.
	Huh? You do remember playing safe don't you?
	I'm sorry, this is the end of the road.
	"Mice84", "Cobra7", "Eagle21", "Whitefrog" see target through the door.

		""" 
		exit(0)
#============================================================================
	def inter_in(self):
		print """
\nGov:	I can confirm without fear and equivovation that the message
	recieved ealier is misleading. You are safe. Yes, I was thinking otherwise.
	But its different now hearing from the horses own mouth. Signals
	reaching me hitherto meant on average you don't have manners to emulate.
	Its ok now. f anything be I will call for you. Enjoy your stay. :)
		""" 
		exit(0)


#============================================================================		
a_game = Game("chl")
a_game.play()