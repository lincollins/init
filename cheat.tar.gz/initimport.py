# Ok Gov Dawn, our initial main file init.py would be imported
# In that, we would not run that again but initimport.py instead
# This is becuase we want to import the moudle here
# Which is our starter file 'def single'
# Let see how it goes
# Ok, Dawn we can confirm without fear and equivocation that it has worked
# What it means in plain words is that, this is going to be our starter file from now
# Got it
# Thank God
# We import the module 'single' because that is where it all starts from
# Interestingly, all other modules in it pick as well.
# Bingo :)

from init import single
single()