#### This is Male's Single
#### We are going to do all Male singles in here
#### We hope to do some import too?
#### Sure, cus the others like 35.py, cheatad.py and the latest failure cheatcrack.py
#### I guess you know the story
#### But Dawn is a real warrior! And Real Warriors never quit!


def chap(self):
	print """

Nar:	Phillipine and her new found friend kept on  chatting. 
		They laughed over a few words and from
	    afar, one would imagine that the've known each other for a 1000 yrs. 
	    With such a slim figure,dark and yet undoubtedly mind 
	    blowing stature, Phillipine is every man's choice. 
	    Or well maybe what the ladies would call their idol. 
	    With firm boobs and rounded butts, she is in her prime 
	    as you would think. And then a robot approaches...
\nRobot:	Hi, I am Mice84, please identify yourself?
\nPhill:	I am Phillipne. Codename PinkBerry. Female.
		"""
	print "\tPhillipine: Kindly mention your name again and your sex. No Codename yet."

	user = raw_input("\t>>> ")

	print """
\nRobot:	You're all welcome. %r doesn't sounds familiar though. Please follow me.

	"""	% user
	print """
\nNar:	Phillipine and %s follows Mice84. I know you would be asking
		yourself if its a gated community. Not that really.
		Its only the Gov's palace among few which is not gated.
		I guess its because of the loads of machines he has around.
		They walk straight to a metal door.
		""" % user
	print """
\nRobot:	This is Mice84. Grant access to entry.
		"""
	print """
\nNar:	The door opens. They all walk into it. 
		And there is the Governor himself.
		With a white suite on and a glass of grapes wine I think in his 
		left hand. He seems to be on the phone. Slim in nature too,
		you would think his belly would be flat, well your guess
		is good a mine :)
		"""
	print """
\nGov:	You may sit down. 
		"""

	if "Male" in user:
		print """
\nGov:	Phillipine I know, but you %r? 
		I doubt you're new here right?
		Kindly tell me about yourself in 5 lines
		""" % user
		print """
\nNar:	In order to continue, kindly run: 'python data.py myself'.
		It should be without the quotes please (' ').
		And in 5 sentences, tell Governor about yourself.
		See you after this. :)

			"""
		exit(0)

	elif "Female" in user:
		print """
\nGov: 	Phillipine I know, but you %r? 
		I doubt you're new here right?
		Kindly tell me about yourself in 5 lines
		""" % user
		exit(0)

		print """
\nNar:	In order to continue, kindly run: 'python data.py myself'.
		It should be without the quotes please (' ').
		And in 5 sentences, tell Governor about yourself.
		See you after this. :)

			"""
	else:
		print "I cant confirm your input please"
		return 'chap'
	
		  


